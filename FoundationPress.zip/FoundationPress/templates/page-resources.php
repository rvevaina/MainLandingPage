<?php
/**
 * Template Name: Resources
 */

//Advanced Custom Fields
$resources_name = get_field('resources_name');
$resources_description = get_field('resources_description');
$image = get_field('image');
$url = get_field('url');
$thumbnail_description = get_field('thumbnail_description');




get_header(); ?>

<?php get_template_part('content', 'hero'); ?>

<div class="container">
    <div class="row" id="primary">
        <div class="content large-12 columns" >


            <h3> <?php echo $resources_name ?></h3>

            <p> <?php echo $resources_description ?> </p>


            <section class="main-content">
                <?php while (have_posts() ) : the_post() ?>

                     <?php the_content(); ?>

                <?php endwhile; ?>

                <?php $loop = new WP_Query(array('post_type' => 'resource', 'orderby' => 'post_id', 'order' => 'ASC') ); ?>

                <hr>
                <div class="resource-row clearfix">
                    <?php while ($loop -> have_posts() ): $loop-> the_post() ?>
                        <div class="resource">
                            <a href="<?php echo $url ?>">
                                <img src="<?php echo $image['url'] ?>" alt="<?php echo $image['alt'] ?>"/>
                                <p><?php echo $thumbnail_description ?></p>
    <!--                            <h3>--><?php //the_title() ?><!--</h3>-->
                                <p><?php the_content() ?></p>
                            </a>
                    </div>
                    <?php endwhile; ?>
<!--                        <p>--><?php //_e( 'Please add content through the Portfolio Post Type.' ); ?><!--</p>-->
<!--                    --><?php //endif; ?>
                </div>
            </section>
        </div>
    </div>
</div>

<?php wp_reset_query(); ?>

<?php get_footer(); ?>

