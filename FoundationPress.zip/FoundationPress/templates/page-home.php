<?php
/**
 * Template Name: Home Page
 */


get_header(); ?>

<?php get_template_part('content', 'herohome'); ?>

<?php get_template_part('content', 'displayboxes'); ?>

<?php get_template_part('content', 'optin'); ?>

<!--Popular Blog Posts-->

<div class="row" id="primary">
    <main id="content" class="large-10 columns large-offset-1">
        <h2 class="blog-title-main">Recent Blog Posts</h2>


        <?php $posts = get_posts( "category=X&numberposts=3&orderby=post_date" ); ?>
        <?php if( $posts ) : ?>
            <?php foreach( $posts as $post ) : setup_postdata( $post ); ?>
            <article <?php post_class('main-content') ?> id="post-<?php the_ID(); ?>">
                <header>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="post-details">
                        <i class="fa fa-user"></i>
                        <?php the_author(); ?>
                        <i class="fa fa-clock-o"></i>
                        <time><?php the_date(); ?></time>
                        <i class="fa fa-folder"></i>
                        <?php the_category(', ')?>
                        <i class="fa fa-tags"></i><a>Tags: </a>
                        <?php the_tags()?>
                        <?php edit_post_link('  Edit', '<i style="float: right" class="fa fa-pencil">', '</i>'); ?>
                    </div>
                </header>
                <?php if (has_post_thumbnail()) { ?>
                    <div class="post-image">
                        <?php the_post_thumbnail(); ?>
                    </div>
                <?php } ?>
                <div class="post-body">
                    <? the_excerpt(); ?>
                </div>
                <footer>
                    <?php wp_link_pages( array('before' => '<nav id="page-nav"><p>' . __( 'Pages:', 'foundationpress' ), 'after' => '</p></nav>' ) ); ?>
                    <p><?php the_tags(); ?></p>
                </footer>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>
</div>

<?php wp_reset_query(); ?>

<?php get_footer(); ?>
