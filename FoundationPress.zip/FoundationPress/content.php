<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage FoundationPress
 * @since FoundationPress 1.0.0
 */

?>

<div id="post-<?php the_ID(); ?>" <?php post_class('blogpost-entry'); ?>>
	<header>
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<div class="post-details">
			<i class="fa fa-user"></i>
			<?php the_author(); ?>
			<i class="fa fa-clock-o"></i>
			<time><?php the_date(); ?></time>
			<i class="fa fa-folder"></i>
			<?php the_category(', ')?>
			<i class="fa fa-tags"></i>
			<?php the_tags()?>
			<?php edit_post_link('  Edit', '<i style="float: right" class="fa fa-pencil">', '</i>'); ?>
		</div>
	</header>
		<?php if (has_post_thumbnail()) { ?>
			<div class="post-image">
				<?php the_post_thumbnail(); ?>
			</div>
		<?php } ?>
		<div class="post-excerpt">
			<? the_excerpt(); ?>
		</div>

</div>
