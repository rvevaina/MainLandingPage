<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "off-canvas-wrap" div and all content after.
 *
 * @package WordPress
 * @subpackage FoundationPress
 * @since FoundationPress 1.0.0
 */

//Advanced Custom Fields

$subscription_text_bottom = get_field('subscription_text_bottom', get_option('page_for_posts'));
$subscription_button_text_bottom = get_field('subscription_button_text_bottom', get_option('page_for_posts'));
$modal_title = get_field('modal_title', get_option('page_for_posts'));
$modal_description = get_field('modal_description', get_option('page_for_posts'));
$modal_subtext = get_field('modal_subtext', get_option('page_for_posts'));

?>

<footer>
	<div id="footer-container">
		<!--Signup-2-->
		<section class="sign-up">
			<div class="overlay"></div>
			<div class="container">
				<h3><?php echo $subscription_text_bottom ?></h3>
				<a href="#" class="button" data-open="optInModal1"><?php echo $subscription_button_text_bottom ?></a>
			</div>
		</section>

		<!--Modal-->

		<div class="reveal" id="optInModal1" data-reveal>
			<h4 class="modal-title"><i class="fa fa-envelope"></i><?php echo $modal_title?></h4>
			<p class="lead"><?php echo $modal_description?></p>
			<form>
				<div class="medium-5 name columns">
					<input type="text" placeholder="Name">
				</div>
				<div class="medium-5 email columns">
					<input type="text" placeholder="Email">
				</div>
				<div class="medium-2 submit columns">
					<input type="submit" class="button" value="Submit">
				</div>
			</form>
			<p class="small"><?php echo $modal_subtext?></p>
			<button class="close-button" data-close aria-label="Close modal" type="button">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

<!--		<div class="row" id="contact">-->
<!--			<div class="social-media">-->
<!--				--><?php
//				if(is_active_sidebar('footer-widgets')){
//					dynamic_sidebar('footer-widgets');
//				}
//				?>
<!--			</div>-->
<!--		</div>-->


		<div class="row" id="contact">
			<div class="social-media large-6 large-offset-3 medium-12 small-12 columns">
				<a href="mailto:rayhanv_me.com"><i class="fa fa-envelope-o fa-4x"></i></a>
				<a href="https://twitter.com/ray_vevaina"><i class="fa fa-twitter fa-4x"></i></a>
				<a href="https://www.instagram.com/rayhan.v/"><i class="fa fa-instagram fa-4x"></i></a>
				<a href="https://medium.com/@ray_vevaina"><i class="fa fa-medium fa-4x"></i></a>
			</div>
		</div>
	</div>
	<div class="copyright">
		<p class="copyright">
			&copy; <?php echo date('Y'); ?> <?php echo get_bloginfo( 'name' ); ?>
		</p>
	</div>
</footer>




<?php wp_footer(); ?>

<script src="https://use.typekit.net/ijz4rrc.js"></script>

</body>
</html>
