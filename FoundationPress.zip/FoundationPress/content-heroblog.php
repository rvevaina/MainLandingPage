
<section id="hero">
    <div class="container">
        <div class="row">
            <div class="large-6 large-offset-3 medium-7 small-12 columns headline">
                <h1 style="text-align: center">
                    Blog
                </h1>
            </div>
            <div class="arrow-down"></div>
        </div>
</section>