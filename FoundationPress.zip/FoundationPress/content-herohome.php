<?php

//Advanced Custom Fields
$name = get_field('name');
$description = get_field('description');
$profile_image = get_field('profile_image');

$thumbnail_url = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
?>

<section id="hero-home">
    <div class="container">
        <div class="row">
            <div class="large-6 large-offset-1 medium-7 small-12 columns headline">
                <h1>
                    <?php if( !empty($name)) :  ?>
                        <?php echo $name; ?>
                    <?php endif; ?>
                </h1>
                <p>
                    <?php if( !empty($description)) :  ?>
                        <?php echo $description; ?>
                    <?php endif; ?>
                </p>
            </div>
            <div class="large-5 columns medium-5 profile-image">
                <?php if( !empty($profile_image)) :  ?>
                    <img class="headshot" src="<?php echo $profile_image['url']; ?>" alt="<?php echo $profile_image['alt']; ?>"/>
                <?php endif; ?>
            </div>
        </div>
        <div class="arrow-down"></div>
    </div>
</section>