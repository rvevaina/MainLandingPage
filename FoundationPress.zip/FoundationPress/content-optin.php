<?php

//Advanced Custom Fields
$subscription_text = get_field('subscription_text');
$subscription_button_text = get_field('subscription_button_text');
?>

<!--Signup-->

<section id="opt-in">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="text small-12 columns">
                <p class="subscribe">
                    <?php echo $subscription_text ?>
                </p>
            </div>
            <div class="optinbutton">
                <a href="#" class="button" data-open="optInModal1"><?php echo $subscription_button_text ?></a>
            </div>
        </div>
    </div>
</section>