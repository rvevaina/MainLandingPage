<?php

//Advanced Custom Fields
$box_1_image = get_field('box_1_image');
$box_1_text = get_field('box_1_text');
$box_1_link = get_field('box_1_link');
$box_1_link_internal = get_field('box_1_link_internal');
$box_2_image = get_field('box_2_image');
$box_2_text = get_field('box_2_text');
$box_2_link = get_field('box_2_link');
$box_2_link_internal = get_field('box_2_link_internal');
$box_3_image = get_field('box_3_image');
$box_3_text = get_field('box_3_text');
$box_3_link = get_field('box_3_link');
$box_3_link_internal = get_field('box_3_link_internal');
$box_4_image = get_field('box_4_image');
$box_4_text = get_field('box_4_text');
$box_4_link = get_field('box_4_link');
$box_4_link_internal = get_field('box_4_link_internal');
?>

<!--Display Boxes-->
<section id="top-row">
    <div class="container row">
        <div class="large-3 medium-4 small-12 block columns">
            <a href="
            <?php if (empty($box_1_link)) {
                echo $box_1_link_internal;
            } else{
                echo $box_1_link;
            } ?> ">
                <div class="tab rcv">
                    <?php if( !empty($box_1_image)) :  ?>
                        <img src=" <?php echo $box_1_image['url']; ?>" alt="<?php echo $box_1_image['alt']; ?>"/>
                    <?php endif; ?>
                </div>
            </a>
            <p><?php echo $box_1_text ?></p>
        </div>
        <div class="large-3 medium-4 small-12 end block columns">
            <a href="
            <?php if (empty($box_2_link)) {
                echo $box_2_link_internal;
            } else{
                echo $box_2_link;
            } ?> ">
                <div class="tab">
                    <?php if( !empty($box_2_image)) :  ?>
                        <img src=" <?php echo $box_2_image['url']; ?>" alt="<?php echo $box_2_image['alt']; ?>"/>
                    <?php endif; ?>
                </div>
            </a>
            <p><?php echo $box_2_text ?></p>
        </div>
        <div class="large-3 medium-4 small-12 block columns">
            <a target="_blank" href="https://medium.com/@ray_vevaina">
                <div class="tab blog">
                    <?php if( !empty($box_3_image)) :  ?>
                        <img src=" <?php echo $box_3_image['url']; ?>" alt="<?php echo $box_3_image['alt']; ?>"/>
                    <?php endif; ?>
                </div>
            </a>
            <p><?php echo $box_3_text ?></p>
        </div>
        <div class="large-3 medium-4 small-12 block columns">
            <a href="#contact">
                <div class="tab">
                    <?php if( !empty($box_4_image)) :  ?>
                        <img src=" <?php echo $box_4_image['url']; ?>" alt="<?php echo $box_4_image['alt']; ?>"/>
                    <?php endif; ?>
                </div>
            </a>
            <p><?php echo $box_4_text ?></p>
        </div>
    </div>
</section>
