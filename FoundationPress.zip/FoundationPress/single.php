<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage FoundationPress
 * @since FoundationPress 1.0.0
 */

get_header(); ?>

<div class="container">
	<div class="row" id="primary">
		<main id="content" class="content large-8 columns">

			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class('main-content') ?> id="post-<?php the_ID(); ?>">
					<header>
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<div class="post-details">
							<i class="fa fa-user"></i>
							<?php the_author(); ?>
							<i class="fa fa-clock-o"></i>
							<time><?php the_date(); ?></time>
							<i class="fa fa-folder"></i>
							<?php the_category(', ')?>
							<i class="fa fa-tags"></i>
							<?php the_tags()?>
							<?php edit_post_link('  Edit', '<i style="float: right" class="fa fa-pencil">', '</i>'); ?>
						</div>
					</header>
					<?php if (has_post_thumbnail()) { ?>
						<div class="post-image">
							<?php the_post_thumbnail(); ?>
						</div>
					<?php } ?>
					<div class="post-body">
						<? the_content(); ?>
					</div>
<!--					<footer>-->
<!--						--><?php //wp_link_pages( array('before' => '<nav id="page-nav"><p>' . __( 'Pages:', 'foundationpress' ), 'after' => '</p></nav>' ) ); ?>
<!--						<p>--><?php //the_tags(); ?><!--</p>-->
<!--					</footer>-->
				</article>
			<?php endwhile;?>
		</main>
		<aside class="large-4 columns">
			<?php get_sidebar(); ?>
		</aside>
	</div>
</div>
<?php if(comments_open() || get_comments_number() ) :
	comments_template();
endif;
?>

<footer>
	<div id="footer-container">
		<!--Signup-2-->
		<section class="sign-up">
			<div class="overlay"></div>
			<div class="container">
				<h3>Ready to take your freelance career to the next level?</h3>
				<a href="#" class="button" data-open="optInModal1">Yes, Sign me up</a>
			</div>
		</section>

		<!--Modal-->

		<div class="reveal" id="optInModal1" data-reveal>
			<h4 class="modal-title"><i class="fa fa-envelope"></i>  Subscribe to our Mailing List</h4>
			<p class="lead"><p>Simply enter your name and email! <br> You will receive specially curated articles on how to make money on your own terms</p>
			<form>
				<div class="medium-5 name columns">
					<input type="text" placeholder="Name">
				</div>
				<div class="medium-5 email columns">
					<input type="text" placeholder="Email">
				</div>
				<div class="medium-2 submit columns">
					<input type="submit" class="button" value="Submit">
				</div>
			</form>
			<p class="small">By providing your email you consent to receiving occasional promotional emails &amp; newsletters. No Spam. No BS. Just good stuff.<br> We respect your privacy &amp; you may unsubscribe at any time.</p>
			<button class="close-button" data-close aria-label="Close modal" type="button">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>


		<div class="row" id="contact">
			<div class="social-media large-6 large-offset-3 medium-12 small-12 columns">
				<a href="mailto:rayhanv_me.com"><i class="fa fa-envelope-o fa-4x"></i></a>
				<a href="https://twitter.com/ray_vevaina"><i class="fa fa-twitter fa-4x"></i></a>
				<a href="https://www.instagram.com/rayhan.v/"><i class="fa fa-instagram fa-4x"></i></a>
				<a href="https://medium.com/@ray_vevaina"><i class="fa fa-medium fa-4x"></i></a>
			</div>
		</div>
	</div>
</footer>
