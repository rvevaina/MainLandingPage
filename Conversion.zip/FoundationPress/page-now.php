<?php
/**
 * Template Name: Now
 */

//Advanced Custom Fields
$now_subhead = get_field('now_subhead');
$now_text = get_field('now_text');
$where_header = get_field('where_header');



get_header(); ?>

<?php get_template_part('content', 'hero'); ?>

<div class="container now">
    <div class="row" id="primary">
        <div class="content large-8 large-offset-2 medium-10 medium-offset-1 small-12 columns">
            <h3 class="content-subhead"> <?php echo $now_subhead ?></h3>
            <p class="text"> <?php echo $now_text ?> </p>
            <h3 class="content-subhead"> <?php echo $where_header ?></h3>
            <?php while ( have_posts() ) : the_post(); ?>
                <article <?php post_class('main-content') ?> id="post-<?php the_ID(); ?>">
                    <?php do_action( 'foundationpress_page_before_entry_content' ); ?>
                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                    <footer>
                        <?php wp_link_pages( array('before' => '<nav id="page-nav"><p>' . __( 'Pages:', 'foundationpress' ), 'after' => '</p></nav>' ) ); ?>
                        <p><?php the_tags(); ?></p>
                    </footer>
                    <?php do_action( 'foundationpress_page_before_comments' ); ?>
                    <?php comments_template(); ?>
                    <?php do_action( 'foundationpress_page_after_comments' ); ?>
                </article>
            <?php endwhile;?>
    </div>
</div>


<?php get_footer(); ?>