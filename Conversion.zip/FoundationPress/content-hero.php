<?php

//Advanced Custom Fields
$name = get_field('name');
$description = get_field('description');
$profile_image = get_field('profile_image');

$thumbnail_url = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
?>

<section id="hero">
    <div class="container">
        <div class="row">
            <div class="large-6 large-offset-3 medium-7 small-12 columns headline">
                <h1 style="text-align: center">
                    <?php if( !empty($name)) :  ?>
                        <?php echo $name; ?>
                    <?php endif; ?>
                </h1>
        </div>
        <div class="arrow-down"></div>
    </div>
</section>