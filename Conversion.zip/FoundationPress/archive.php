<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage FoundationPress
 * @since FoundationPress 1.0.0
 */

get_header(); ?>


<div class="container">
	<div class="row" id="primary">
		<main id="content" class="content large-8 columns">

				<article class="main-content">
				<?php if ( have_posts() ) : ?>

				<?php /* Start the Loop */ ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'content', get_post_format() ); ?>
				<?php endwhile; ?>

				<?php else : ?>
					<?php get_template_part( 'content', 'none' ); ?>

				<?php endif; // End have_posts() check. ?>

				<?php /* Display navigation to next/previous pages when applicable */ ?>
				<?php if ( function_exists( 'foundationpress_pagination' ) ) { foundationpress_pagination(); } else if ( is_paged() ) { ?>
					<nav id="post-nav">
						<div class="post-previous"><?php next_posts_link( __( '&larr; Older posts', 'foundationpress' ) ); ?></div>
						<div class="post-next"><?php previous_posts_link( __( 'Newer posts &rarr;', 'foundationpress' ) ); ?></div>
					</nav>
				<?php } ?>

				</article>
			</main>

		<aside class="large-4 columns">
			<?php get_sidebar(); ?>
		</aside>
	</div>
</div>


<footer>
	<div id="footer-container">
		<!--Signup-2-->
		<section class="sign-up">
			<div class="overlay"></div>
			<div class="container">
				<h3>Ready to take your freelance career to the next level?</h3>
				<a href="#" class="button" data-open="optInModal1">Yes, Sign me up</a>
			</div>
		</section>

		<!--Modal-->

		<div class="reveal" id="optInModal1" data-reveal>
			<h4 class="modal-title"><i class="fa fa-envelope"></i>  Subscribe to our Mailing List</h4>
			<p class="lead"><p>Simply enter your name and email! <br> You will receive specially curated articles on how to make money on your own terms</p>
			<form>
				<div class="medium-5 name columns">
					<input type="text" placeholder="Name">
				</div>
				<div class="medium-5 email columns">
					<input type="text" placeholder="Email">
				</div>
				<div class="medium-2 submit columns">
					<input type="submit" class="button" value="Submit">
				</div>
			</form>
			<p class="small">By providing your email you consent to receiving occasional promotional emails &amp; newsletters. No Spam. No BS. Just good stuff.<br> We respect your privacy &amp; you may unsubscribe at any time.</p>
			<button class="close-button" data-close aria-label="Close modal" type="button">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>


		<div class="row" id="contact">
			<div class="social-media large-6 large-offset-3 medium-12 small-12 columns">
				<a href="mailto:rayhanv_me.com"><i class="fa fa-envelope-o fa-4x"></i></a>
				<a href="https://twitter.com/ray_vevaina"><i class="fa fa-twitter fa-4x"></i></a>
				<a href="https://www.instagram.com/rayhan.v/"><i class="fa fa-instagram fa-4x"></i></a>
				<a href="https://medium.com/@ray_vevaina"><i class="fa fa-medium fa-4x"></i></a>
			</div>
		</div>
	</div>
</footer>
